package com.senati.diagnosticomedicoia;

import java.io.File;
import weka.classifiers.meta.FilteredClassifier;
import weka.classifiers.trees.RandomForest;
import weka.core.Instances;
import weka.core.converters.CSVLoader;
import weka.core.SerializationHelper;
import weka.filters.Filter;
import weka.filters.MultiFilter;
import weka.filters.unsupervised.attribute.Remove;
import weka.filters.unsupervised.attribute.StringToWordVector;

public class DiagnosticoMedicoIA {

    public static void main(String[] args) {
        try {
            System.out.println("1. Cargando dataset Healthcare.csv...");
            CSVLoader loader = new CSVLoader();
            loader.setSource(new File("Healthcare.csv"));
            loader.setFieldSeparator(";"); 
            
            Instances data = loader.getDataSet();

            data.setClassIndex(data.numAttributes() - 1);

            System.out.println("2. Configurando filtros...");
            
            Remove removeFilter = new Remove();
            removeFilter.setAttributeIndices("1,2,3");
            
            StringToWordVector wordToVector = new StringToWordVector();
            wordToVector.setAttributeIndices("first"); 
            wordToVector.setLowerCaseTokens(true);
            wordToVector.setWordsToKeep(500); 
            
            MultiFilter multiFilter = new MultiFilter();
            multiFilter.setFilters(new Filter[]{removeFilter, wordToVector});

            RandomForest classifier = new RandomForest();
            classifier.setNumIterations(200); 
            classifier.setMaxDepth(10);

            FilteredClassifier fc = new FilteredClassifier();
            fc.setFilter(multiFilter);
            fc.setClassifier(classifier);

            System.out.println("3. Entrenando el modelo (RandomForest Afinado)...");
            fc.buildClassifier(data); 

            System.out.println("4. Guardando el modelo entrenado...");
            SerializationHelper.write("modelo_diagnostico.model", fc);
            
            System.out.println("¡EXITO! Nuevo modelo optimizado guardado.");

        } catch (Exception e) {
            System.out.println("Ocurrio un error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}