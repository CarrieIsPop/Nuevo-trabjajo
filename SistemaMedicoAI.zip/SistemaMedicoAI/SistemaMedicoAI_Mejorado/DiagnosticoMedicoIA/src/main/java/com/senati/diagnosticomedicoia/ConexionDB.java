/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.senati.diagnosticomedicoia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionDB {
    
    // Configuración de tu XAMPP
    private static final String URL = "jdbc:mysql://localhost:3306/sistema_medico?serverTimezone=UTC";
    private static final String USER = "root"; // Usuario por defecto de XAMPP
    private static final String PASS = "";     // Contraseña por defecto (vacia)

    public static Connection conectar() {
        Connection cons = null;
        try {
            cons = DriverManager.getConnection(URL, USER, PASS);
            System.out.println("¡Conexión a BD exitosa!");
        } catch (SQLException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return cons;
    }
}