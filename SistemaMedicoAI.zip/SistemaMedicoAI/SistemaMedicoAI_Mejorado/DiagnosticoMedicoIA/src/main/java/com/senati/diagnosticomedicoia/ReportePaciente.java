/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.senati.diagnosticomedicoia;

import javax.swing.*;
import java.awt.*;
import java.awt.print.PrinterException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ReportePaciente extends JFrame {

    private JTextArea areaReporte;
    private JButton btnImprimir, btnCerrar;
    private String dniPaciente;

    public ReportePaciente(String dni) {
        this.dniPaciente = dni;
        
        setTitle("Informe Médico del Paciente");
        setSize(500, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel lblTitulo = new JLabel("HISTORIAL CLÍNICO", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(lblTitulo, BorderLayout.NORTH);

        areaReporte = new JTextArea();
        areaReporte.setEditable(false);
        areaReporte.setFont(new Font("Consolas", Font.PLAIN, 14)); 
        areaReporte.setMargin(new Insets(15, 15, 15, 15));
        areaReporte.setLineWrap(true);
        areaReporte.setWrapStyleWord(true);
        JScrollPane scroll = new JScrollPane(areaReporte);
        add(scroll, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel(new FlowLayout());
        btnImprimir = new JButton("🖨️ Imprimir");
        btnCerrar = new JButton("Cerrar");
        
        panelBotones.add(btnImprimir);
        panelBotones.add(btnCerrar);
        add(panelBotones, BorderLayout.SOUTH);
        
        btnImprimir.addActionListener(e -> imprimirReporte());
        btnCerrar.addActionListener(e -> this.dispose());

        generarReporteDesdeBD();
    }

    private void generarReporteDesdeBD() {
        try {
            Connection con = ConexionDB.conectar();
            String sql = "SELECT * FROM pacientes WHERE dni = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, dniPaciente);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                StringBuilder sb = new StringBuilder();
                sb.append("====================================\n");
                sb.append("   REPORTE MÉDICO DIGITAL IA\n");
                sb.append("====================================\n\n");
                
                sb.append("DATOS DEL PACIENTE:\n");
                sb.append("-------------------\n");
                sb.append("Nombre:   ").append(rs.getString("nombre")).append(" ").append(rs.getString("apellidos")).append("\n");
                sb.append("DNI:      ").append(rs.getString("dni")).append("\n");
                sb.append("Edad:     ").append(rs.getInt("edad")).append(" años\n");
                sb.append("Contacto: ").append(rs.getString("gmail")).append("\n\n");
                
                sb.append("HISTORIAL DE DIAGNÓSTICO RECIENTE:\n");
                sb.append("----------------------------------\n");
                
                String historial = rs.getString("historial_diagnostico");
                if (historial == null || historial.isEmpty()) {
                    sb.append("(Sin diagnósticos previos registrados)\n");
                } else {
                    sb.append(historial);
                }
                
                sb.append("\n\nIsenati 2025\n");
                sb.append("====================================\n");

                areaReporte.setText(sb.toString());
                
            } else {
                areaReporte.setText("Error: No se encontró al paciente con DNI " + dniPaciente);
            }
            con.close();

        } catch (Exception e) {
            areaReporte.setText("Error de conexión: " + e.getMessage());
            e.printStackTrace();
        }
    }
    

    private void imprimirReporte() {
        try {
            boolean complete = areaReporte.print();
            if (complete) {
                JOptionPane.showMessageDialog(this, "Impresión completada", "Información", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Impresión cancelada", "Información", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (PrinterException pe) {
            JOptionPane.showMessageDialog(this, "Error al imprimir: " + pe.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}