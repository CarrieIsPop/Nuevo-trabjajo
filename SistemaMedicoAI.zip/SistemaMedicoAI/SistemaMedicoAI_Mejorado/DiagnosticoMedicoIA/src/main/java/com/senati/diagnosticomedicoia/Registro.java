/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.senati.diagnosticomedicoia;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeParseException;

public class Registro extends JFrame {

    private JTextField txtNombre, txtApellidos, txtDNI, txtGmail, txtFechaNac;
    private JPasswordField txtPassword;
    private JButton btnRegistrar, btnIrLogin;

    public Registro() {
        // CONFIGURACION DE VENTANA
        setTitle("Registro de Paciente - Sistema IA");
        setSize(450, 750); // Tamaño corregido para que quepa todo
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null); 
        getContentPane().setBackground(new Color(240, 248, 255)); 

        // TITULO
        JLabel lblTitulo = new JLabel("Crear Cuenta Nueva");
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 24));
        lblTitulo.setForeground(new Color(25, 25, 112)); 
        lblTitulo.setBounds(100, 20, 300, 30);
        add(lblTitulo);

        // CAMPOS
        crearEtiqueta("Nombres:", 80);
        txtNombre = crearCampoTexto(80);

        crearEtiqueta("Apellidos:", 140);
        txtApellidos = crearCampoTexto(140);

        crearEtiqueta("DNI (8 dígitos):", 200);
        txtDNI = crearCampoTexto(200);

        crearEtiqueta("Gmail (@gmail.com):", 260);
        txtGmail = crearCampoTexto(260);

        crearEtiqueta("Fecha Nacimiento (AAAA-MM-DD):", 320);
        txtFechaNac = crearCampoTexto(320);
        txtFechaNac.setToolTipText("Ejemplo: 2000-05-25");

        crearEtiqueta("Contraseña:", 380);
        txtPassword = new JPasswordField();
        txtPassword.setBounds(50, 410, 340, 30);
        add(txtPassword);

        // BOTON REGISTRARME
        btnRegistrar = new JButton("REGISTRARME");
        btnRegistrar.setBounds(50, 470, 340, 40);
        btnRegistrar.setBackground(new Color(30, 144, 255)); // Azul Dodger
        btnRegistrar.setForeground(Color.WHITE);            // Letra Blanca
        btnRegistrar.setFont(new Font("SansSerif", Font.BOLD, 14));
        btnRegistrar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        add(btnRegistrar);
        
        // BOTON IR AL LOGIN
        btnIrLogin = new JButton("¿Ya tienes cuenta? Inicia Sesión");
        btnIrLogin.setBounds(50, 520, 340, 30);
        btnIrLogin.setContentAreaFilled(false);
        btnIrLogin.setBorderPainted(false);
        btnIrLogin.setForeground(Color.BLUE);
        btnIrLogin.setCursor(new Cursor(Cursor.HAND_CURSOR));
        add(btnIrLogin);


        btnRegistrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                validarYRegistrar();
            }
        });
        
        btnIrLogin.addActionListener(e -> {
             new Login().setVisible(true);
             this.dispose();
        });
    }

    // LÓGICA DE VALIDACIÓN
    private void validarYRegistrar() {
        String nombre = txtNombre.getText().trim();
        String apellidos = txtApellidos.getText().trim();
        String dni = txtDNI.getText().trim();
        String gmail = txtGmail.getText().trim();
        String fecha = txtFechaNac.getText().trim();
        String pass = new String(txtPassword.getPassword());

        if (nombre.isEmpty() || apellidos.isEmpty() || dni.isEmpty() || gmail.isEmpty() || fecha.isEmpty() || pass.isEmpty()) {
            mostrarError("Por favor, complete todos los campos.");
            return;
        }

        if (!nombre.matches("^[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]+$")) {
            mostrarError("El NOMBRE solo debe contener letras.");
            return;
        }
        if (!apellidos.matches("^[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]+$")) {
            mostrarError("Los APELLIDOS solo deben contener letras.");
            return;
        }

        if (!dni.matches("\\d{8}")) {
            mostrarError("El DNI debe tener exactamente 8 números.");
            return;
        }

        if (!gmail.matches("^[a-zA-Z0-9._%+-]+@gmail\\.com$")) {
            mostrarError("El correo debe ser válido y terminar en @gmail.com");
            return;
        }

        int edadCalculada = 0;
        try {
            LocalDate fechaNacimiento = LocalDate.parse(fecha); 
            LocalDate hoy = LocalDate.now();
            
            if (fechaNacimiento.isAfter(hoy)) {
                mostrarError("La fecha de nacimiento no puede ser futura.");
                return;
            }
            
            edadCalculada = Period.between(fechaNacimiento, hoy).getYears();
            
            if (edadCalculada < 0 || edadCalculada > 120) {
                 mostrarError("Edad no válida calculada.");
                 return;
            }

        } catch (DateTimeParseException ex) {
            mostrarError("Formato de fecha incorrecto. Use: AAAA-MM-DD (Ej: 2000-05-25)");
            return;
        }

        guardarEnBaseDeDatos(nombre, apellidos, dni, gmail, fecha, edadCalculada, pass);
    }

    private void guardarEnBaseDeDatos(String nom, String ape, String dni, String mail, String fec, int edad, String pass) {
        Connection con = ConexionDB.conectar();
        
        if (con != null) {
            try {
                String sql = "INSERT INTO pacientes (nombre, apellidos, dni, gmail, fecha_nacimiento, edad, password) VALUES (?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setString(1, nom);
                pst.setString(2, ape);
                pst.setString(3, dni);
                pst.setString(4, mail);
                pst.setString(5, fec); 
                pst.setInt(6, edad);   
                pst.setString(7, pass);
                pst.executeUpdate();
                
                JOptionPane.showMessageDialog(this, "¡Registro Exitoso!\nTu edad calculada es: " + edad + " años.");
                
                // Limpiar
                txtNombre.setText(""); txtApellidos.setText(""); txtDNI.setText("");
                txtGmail.setText(""); txtFechaNac.setText(""); txtPassword.setText("");
                
            } catch (Exception e) {
                if(e.getMessage().contains("Duplicate entry")) {
                     mostrarError("El DNI o Gmail ya están registrados.");
                } else {
                     mostrarError("Error al guardar: " + e.getMessage());
                }
            }
        }
    }
    
    private void crearEtiqueta(String texto, int y) {
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lbl.setBounds(50, y, 200, 20);
        add(lbl);
    }

    private JTextField crearCampoTexto(int y) {
        JTextField txt = new JTextField();
        txt.setBounds(50, y + 25, 340, 30);
        txt.setFont(new Font("SansSerif", Font.PLAIN, 14));
        add(txt);
        return txt;
    }
    
    private void mostrarError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error de Validación", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> {
            new Registro().setVisible(true);
        });
    }
}