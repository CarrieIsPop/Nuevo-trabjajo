/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.senati.diagnosticomedicoia;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import weka.classifiers.meta.FilteredClassifier;
import weka.core.Attribute;
import weka.core.DenseInstance;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.SerializationHelper;
import weka.core.converters.CSVLoader;

public class AppDiagnostico extends JFrame {

    private JTextArea areaChat;
    private JTextField txtMensaje;
    private JButton btnEnviar;
    private JPanel panelSur;

    private FilteredClassifier modelo;
    private Instances estructura;
    
    private int estadoChat = 0; 
    private int sintomasSolicitados = 0;
    private int sintomasContados = 0;
    private StringBuilder sintomasRecibidos = new StringBuilder();
    
    private Map<String, String> diccionario;
    private String dniUsuarioActual;

    public AppDiagnostico(String dniUsuario) {
        this.dniUsuarioActual = dniUsuario;
        
        setTitle("Dr. IA - Usuario: " + dniUsuario);
        setSize(380, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        areaChat = new JTextArea();
        areaChat.setEditable(false);
        areaChat.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
        areaChat.setBackground(new Color(245, 245, 245));
        areaChat.setMargin(new Insets(10, 10, 10, 10));
        areaChat.setLineWrap(true);
        areaChat.setWrapStyleWord(true);
        
        JScrollPane scroll = new JScrollPane(areaChat);
        scroll.setBorder(null);
        add(scroll, BorderLayout.CENTER);

        panelSur = new JPanel(new BorderLayout());
        panelSur.setBorder(new EmptyBorder(10, 10, 10, 10));
        panelSur.setBackground(Color.WHITE);

        txtMensaje = new JTextField();
        txtMensaje.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtMensaje.addActionListener(e -> procesarMensajeUsuario());

        btnEnviar = new JButton("➤");
        btnEnviar.setBackground(new Color(0, 122, 255));
        btnEnviar.setForeground(Color.WHITE);
        btnEnviar.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnEnviar.setFocusPainted(false);
        btnEnviar.addActionListener(e -> procesarMensajeUsuario());

        panelSur.add(txtMensaje, BorderLayout.CENTER);
        panelSur.add(btnEnviar, BorderLayout.EAST);
        add(panelSur, BorderLayout.SOUTH);

        cargarDiccionario();
        cargarModeloIA();
        
        agregarMensajeIA("¡Hola! Soy tu asistente médico virtual.");
        agregarMensajeIA("Para comenzar, dime: ¿Cuántos síntomas diferentes sientes hoy?");
        estadoChat = 1; 
    }

    private void procesarMensajeUsuario() {
        String texto = txtMensaje.getText().trim();
        if (texto.isEmpty()) return;

        agregarMensajeUsuario(texto);
        txtMensaje.setText("");

        try {
            if (estadoChat == 1) { 
                Pattern p = Pattern.compile("\\d+");
                Matcher m = p.matcher(texto);

                if (m.find()) {
                    String numeroEncontrado = m.group();
                    sintomasSolicitados = Integer.parseInt(numeroEncontrado);
                    
                    if (sintomasSolicitados <= 0) {
                        agregarMensajeIA("Necesito que tengas al menos 1 síntoma para ayudarte.");
                    } else {
                        estadoChat = 2; 
                        sintomasContados = 0;
                        sintomasRecibidos = new StringBuilder();
                        agregarMensajeIA("Entendido (" + sintomasSolicitados + " síntomas). Dime el síntoma número 1:");
                    }
                } else {
                    agregarMensajeIA("No entendí la cantidad. Por favor escribe un número (ej: 'tengo 3 síntomas').");
                }
            } 
            else if (estadoChat == 2) { 
                String sintomaTraducido = traducirSintoma(texto);
                
                if (sintomasContados > 0) sintomasRecibidos.append(", ");
                sintomasRecibidos.append(sintomaTraducido);
                sintomasContados++;

                if (sintomasContados < sintomasSolicitados) {
                    agregarMensajeIA("Anotado. Dime el síntoma número " + (sintomasContados + 1) + ":");
                } else {
                    realizarDiagnostico();
                }
            }
            else if (estadoChat == 3) { 
                agregarMensajeIA("El diagnóstico ha finalizado. Por favor cierra sesión o ve el informe.");
            }

        } catch (Exception e) {
            agregarMensajeIA("Ocurrió un error. Intenta de nuevo.");
            e.printStackTrace();
        }
    }

    private void realizarDiagnostico() {
        agregarMensajeIA("Analizando tus síntomas: " + sintomasRecibidos.toString() + "...");
        
        Timer timer = new Timer(1500, e -> {
            try {
                Instance paciente = new DenseInstance(estructura.numAttributes());
                paciente.setDataset(estructura);

                Attribute attrID = estructura.attribute("Patient_ID");
                if (attrID.isNominal()) paciente.setValue(attrID, attrID.value(0));
                else paciente.setValue(attrID, 0);

                paciente.setValue(estructura.attribute("Age"), 30); 

                Attribute attrGender = estructura.attribute("Gender");
                paciente.setValue(attrGender, attrGender.value(0)); 
                
                paciente.setValue(estructura.attribute("Symptoms"), sintomasRecibidos.toString());
                paciente.setValue(estructura.attribute("Symptom_Count"), sintomasSolicitados);

                
                double[] probs = modelo.distributionForInstance(paciente);
                Attribute claseEnfermedad = estructura.classAttribute();

                List<Map.Entry<String, Double>> listaProbabilidades = new ArrayList<>();
                for (int i = 0; i < probs.length; i++) {
                    String enfermedad = claseEnfermedad.value(i);
                    double probabilidad = probs[i] * 100;
                    listaProbabilidades.add(new AbstractMap.SimpleEntry<>(enfermedad, probabilidad));
                }

                listaProbabilidades.sort((entry1, entry2) -> entry2.getValue().compareTo(entry1.getValue()));

                StringBuilder resultadoFinal = new StringBuilder();
                resultadoFinal.append("TOP 3 POSIBLES CAUSAS:\n");
                for (int i = 0; i < Math.min(3, listaProbabilidades.size()); i++) {
                    Map.Entry<String, Double> entry = listaProbabilidades.get(i);
                    resultadoFinal.append((i + 1) + ". " + entry.getKey().toUpperCase());
                    resultadoFinal.append(" (" + String.format("%.1f", entry.getValue()) + "%)\n");
                }

                agregarMensajeIA("--- DIAGNÓSTICO COMPLETO ---");
                agregarMensajeIA(resultadoFinal.toString().trim());
                agregarMensajeIA("Recuerda: Esto es solo una ayuda. Visita a un médico.");
                
                guardarResultadoEnBD(sintomasRecibidos.toString(), resultadoFinal.toString().trim());

                estadoChat = 3; 
                txtMensaje.setEnabled(false);
                btnEnviar.setEnabled(false);
                
                agregarBotonInforme();

            } catch (Exception ex) {
                agregarMensajeIA("Error al calcular el diagnóstico.");
                System.out.println("ERROR DETALLADO: " + ex.getMessage());
                ex.printStackTrace();
            }
        });
        timer.setRepeats(false);
        timer.start();
    }
    
    private void guardarResultadoEnBD(String sintomas, String reporteCompleto) {
        agregarMensajeIA("Guardando resultado en tu historial médico...");
        try {
            Connection con = ConexionDB.conectar();
            
            String reporteFinalBD = "Fecha: " + java.time.LocalDate.now() + "\nSíntomas: [" + sintomas + "]\n\n" + reporteCompleto;
            
            String sql = "UPDATE pacientes SET historial_diagnostico = ? WHERE dni = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, reporteFinalBD);
            pst.setString(2, dniUsuarioActual);
            
            int filasAfectadas = pst.executeUpdate();
            if(filasAfectadas > 0) {
                 agregarMensajeIA("¡Historial actualizado correctamente!");
            } else {
                 agregarMensajeIA("Error: No se pudo guardar en el historial.");
            }
            con.close();
        } catch (Exception ex) {
             agregarMensajeIA("Error de BD: " + ex.getMessage());
             ex.printStackTrace();
        }
    }
    
    private void agregarBotonInforme() {
        JButton btnInforme = new JButton("🖨️ VER INFORME COMPLETO");
        btnInforme.setBackground(new Color(40, 167, 69));
        btnInforme.setForeground(Color.WHITE);
        btnInforme.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnInforme.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btnInforme.addActionListener(ev -> {
            new ReportePaciente(dniUsuarioActual).setVisible(true);
        });
        
        panelSur.remove(txtMensaje);
        panelSur.add(btnInforme, BorderLayout.CENTER);
        panelSur.revalidate();
        panelSur.repaint();
    }


    private void cargarModeloIA() {
        try {
            modelo = (FilteredClassifier) SerializationHelper.read("modelo_diagnostico.model");
            CSVLoader loader = new CSVLoader();
            loader.setSource(new File("Healthcare.csv"));
            loader.setFieldSeparator(";"); 
            loader.setStringAttributes("4");
            estructura = loader.getStructure();
            estructura.setClassIndex(estructura.numAttributes() - 1);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error cargando IA: " + e.getMessage() + "\n¿Tienes los archivos .model y .csv en la carpeta del proyecto?");
            System.exit(1);
        }
    }

    private void cargarDiccionario() {
        diccionario = new HashMap<>();
        // 1. DOLORES
        diccionario.put("dolor de espalda", "back pain"); diccionario.put("espalda", "back pain");
        diccionario.put("dolor de pecho", "chest pain"); diccionario.put("pecho", "chest pain");
        diccionario.put("dolor muscular", "muscle pain"); diccionario.put("músculos", "muscle pain"); diccionario.put("musculos", "muscle pain");
        diccionario.put("dolor de articulaciones", "joint pain"); diccionario.put("articulaciones", "joint pain");
        diccionario.put("dolor de garganta", "sore throat"); diccionario.put("garganta", "sore throat");
        diccionario.put("dolor abdominal", "abdominal pain"); diccionario.put("estomago", "abdominal pain"); diccionario.put("estómago", "abdominal pain"); diccionario.put("estomacal", "abdominal pain");
        diccionario.put("dolor de cabeza", "headache"); diccionario.put("cabeza", "headache"); diccionario.put("jaqueca", "headache");
        // 2. RESPIRATORIOS
        diccionario.put("tos", "cough");
        diccionario.put("estornudos", "sneezing"); diccionario.put("estornudo", "sneezing");
        diccionario.put("falta de aire", "shortness of breath"); diccionario.put("dificultad para respirar", "shortness of breath"); diccionario.put("ahogo", "shortness of breath");
        diccionario.put("secrecion nasal", "runny nose"); diccionario.put("secreción nasal", "runny nose"); diccionario.put("mocos", "runny nose");
        // 3. ESTOMACALES
        diccionario.put("vomito", "vomiting"); diccionario.put("vómito", "vomiting");
        diccionario.put("diarrea", "diarrhea");
        diccionario.put("nauseas", "nausea"); diccionario.put("náuseas", "nausea");
        diccionario.put("perdida de apetito", "appetite loss"); diccionario.put("pérdida de apetito", "appetite loss"); diccionario.put("sin hambre", "appetite loss");
        // 4. MENTALES/GENERALES
        diccionario.put("fiebre", "fever"); diccionario.put("calentura", "fever");
        diccionario.put("fatiga", "fatigue"); diccionario.put("cansancio", "fatigue");
        diccionario.put("insomnio", "insomnia");
        diccionario.put("ansiedad", "anxiety"); diccionario.put("nervios", "anxiety");
        diccionario.put("depresion", "depression"); diccionario.put("depresión", "depression"); diccionario.put("tristeza", "depression");
        // 5. PIEL Y OTROS
        diccionario.put("sarpullido", "rash"); diccionario.put("erupcion", "rash"); diccionario.put("manchas", "rash");
        diccionario.put("sudoracion", "sweating"); diccionario.put("sudor", "sweating");
        diccionario.put("hinchazon", "swelling"); diccionario.put("hinchazón", "swelling");
        diccionario.put("temblores", "tremors");
        // 6. PESO Y VISION
        diccionario.put("vision borrosa", "blurred vision");
        diccionario.put("mareos", "dizziness");
        diccionario.put("perdida de peso", "weight loss"); diccionario.put("bajar de peso", "weight loss");
        diccionario.put("aumento de peso", "weight gain"); diccionario.put("subir de peso", "weight gain");
    }

    private String traducirSintoma(String input) {
        String clave = input.toLowerCase().trim();
        if (diccionario.containsKey(clave)) return diccionario.get(clave);
        for (Map.Entry<String, String> entry : diccionario.entrySet()) {
            if (clave.contains(entry.getKey())) return entry.getValue();
        }
        return input;
    }

    private void agregarMensajeIA(String texto) {
        areaChat.append("\n 🤖 DR. IA:\n " + texto + "\n");
        areaChat.setCaretPosition(areaChat.getDocument().getLength()); 
    }

    private void agregarMensajeUsuario(String texto) {
        areaChat.append("\n 👤 TÚ:\n " + texto + "\n");
        areaChat.setCaretPosition(areaChat.getDocument().getLength());
    }
}