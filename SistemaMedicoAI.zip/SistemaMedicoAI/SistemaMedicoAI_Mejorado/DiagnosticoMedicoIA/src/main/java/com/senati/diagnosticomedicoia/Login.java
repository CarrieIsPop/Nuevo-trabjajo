/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.senati.diagnosticomedicoia;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Login extends JFrame {

    private JTextField txtGmail;
    private JPasswordField txtPassword;
    private JButton btnIngresar, btnIrRegistro;

    public Login() {
        // CONFIGURACION DE LA VENTANA
        setTitle("Acceso al Sistema");
        setSize(400, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        
        // Color de fondo
        getContentPane().setBackground(new Color(240, 248, 255));

        // TITULO
        JLabel lblTitulo = new JLabel("Iniciar Sesión");
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 26));
        lblTitulo.setForeground(new Color(25, 25, 112));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBounds(0, 30, 400, 40);
        add(lblTitulo);

        // CAMPOS
        crearEtiqueta("Correo Electrónico:", 100);
        txtGmail = new JTextField();
        txtGmail.setBounds(50, 130, 280, 35);
        txtGmail.setFont(new Font("SansSerif", Font.PLAIN, 14));
        add(txtGmail);

        crearEtiqueta("Contraseña:", 180);
        txtPassword = new JPasswordField();
        txtPassword.setBounds(50, 210, 280, 35);
        add(txtPassword);

        // BOTON INGRESAR
        btnIngresar = new JButton("INGRESAR");
        btnIngresar.setBounds(50, 280, 280, 45);
        btnIngresar.setBackground(new Color(0, 128, 0));
        btnIngresar.setForeground(Color.WHITE);  
        btnIngresar.setFont(new Font("SansSerif", Font.BOLD, 16));
        btnIngresar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        add(btnIngresar);

        // BOTON REGISTRO
        btnIrRegistro = new JButton("¿No tienes cuenta? Regístrate aquí");
        btnIrRegistro.setBounds(50, 340, 280, 30);
        btnIrRegistro.setContentAreaFilled(false);
        btnIrRegistro.setBorderPainted(false);
        btnIrRegistro.setForeground(new Color(0, 102, 204));
        btnIrRegistro.setCursor(new Cursor(Cursor.HAND_CURSOR));
        add(btnIrRegistro);

        // ACCIONES
        
        btnIngresar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                autenticarUsuario();
            }
        });

        btnIrRegistro.addActionListener(e -> {
            new Registro().setVisible(true);
            this.dispose(); 
        });
    }

    private void autenticarUsuario() {
        String correo = txtGmail.getText().trim();
        String pass = new String(txtPassword.getPassword());

        if (correo.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese correo y contraseña.");
            return;
        }

        try {
            Connection con = ConexionDB.conectar();
            String sql = "SELECT dni, nombre FROM pacientes WHERE gmail=? AND password=?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, correo);
            pst.setString(2, pass);
            
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String nombreUsuario = rs.getString("nombre");
                String dniEncontrado = rs.getString("dni"); 
                
                JOptionPane.showMessageDialog(this, "¡Bienvenido, " + nombreUsuario + "!");
                this.dispose(); 
                
                new AppDiagnostico(dniEncontrado).setVisible(true);
                
            } else {
                JOptionPane.showMessageDialog(this, "Correo o contraseña incorrectos.", "Error de Acceso", JOptionPane.ERROR_MESSAGE);
            }
            con.close(); 

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error de conexión: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void crearEtiqueta(String texto, int y) {
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 12));
        lbl.setBounds(50, y, 200, 20);
        add(lbl);
    }

    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> {
            new Login().setVisible(true);
        });
    }
}